﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyOriginalHousesApp.Models
{
    public class User
    {
        public string Name;
        public string Surname;
        public string Email;
        public string Password;
        public byte Age;
    }
}
