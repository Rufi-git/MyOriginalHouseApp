﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyOriginalHousesApp.Models
{
    public static class Users
    {
        private static User[] _users;
        private static int _counter;
        static Users()
        {
            _users = new User[5];
            _counter = 0;
            User user = new User();
            user.Name = "Sadiq";
            user.Surname = "Agayev";
            user.Email = "sadiq@gmail.com";
            user.Age = 17;
            user.Password = "sadiq123";

            Add(user);
        }

        public static void Add(User user)
        {
            if(_counter != 5)
            {
                _users[_counter] = user;
                _counter++;
            }
            else
            {
                MessageBox.Show("User list is full");
            }
        }

        public static User GetUserByEmail(string email)
        {
            User foundedUser = null;
            foreach (User user in _users)
            {
                if (user != null && user.Email == email)
                {
                    foundedUser = user;
                    break;
                }
            }
            return foundedUser;
        }

        public static User GetUserByParams(string email,string password)
        {
            User foundedUser = null;
            foreach (User user in _users)
            {
                if (user != null && user.Email == email && user.Password == password)
                {
                    foundedUser = user;
                    break;
                }
            }
            return foundedUser;
        }
        public static int UsersCount()
        {
            return _counter;
        }
    }
}
