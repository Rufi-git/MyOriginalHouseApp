﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyOriginalHousesApp.Models
{
    public class Home
    {
        public string Seller;
        public string Address;
        public decimal Price;
    }
}
