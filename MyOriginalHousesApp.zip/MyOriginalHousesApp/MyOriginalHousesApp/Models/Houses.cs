﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyOriginalHousesApp.Models
{
    public static class Houses
    {
        public static Home[] _home;
        private static int _counter;
        
        static Houses()
        {
            _home = new Home[35];
            _counter = 0;
        }

        public static void Add(Home home)
        {
            if (_counter != 5)
            {
                _home[_counter] = home;
                _counter++;
            }
            else
            {
                MessageBox.Show("User list is full!");
            }
        }

        public static Home[] GetHousesByUser(string email)
        {
            Home[] foundedUser = new Home[5];
            int counter = 0;
            foreach(Home home in _home)
            {
                if(home!=null && home.Seller == email)
                {
                    foundedUser[counter] = home;
                    counter++;
                }
            }
            Array.Resize(ref foundedUser, counter);
            return foundedUser;
        }

        public static int HomeCount()
        {
            return _counter;
        }

        public static int UserHomeCount(string email)
        {
            return GetHousesByUser(email).Length;
        }
    }
}
