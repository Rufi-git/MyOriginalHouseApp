﻿namespace MyOriginalHousesApp.Components
{
    partial class LoginRegisterControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txbx_password = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txbx_email = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.common_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txbx_password
            // 
            this.txbx_password.Location = new System.Drawing.Point(0, 94);
            this.txbx_password.Name = "txbx_password";
            this.txbx_password.Size = new System.Drawing.Size(324, 20);
            this.txbx_password.TabIndex = 9;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(-3, 73);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(83, 18);
            this.lbl_password.TabIndex = 8;
            this.lbl_password.Text = "Password";
            // 
            // txbx_email
            // 
            this.txbx_email.Location = new System.Drawing.Point(0, 21);
            this.txbx_email.Name = "txbx_email";
            this.txbx_email.Size = new System.Drawing.Size(324, 20);
            this.txbx_email.TabIndex = 7;
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(-3, 0);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(55, 18);
            this.lbl_email.TabIndex = 6;
            this.lbl_email.Text = "Email:";
            // 
            // common_btn
            // 
            this.common_btn.Location = new System.Drawing.Point(0, 141);
            this.common_btn.Name = "common_btn";
            this.common_btn.Size = new System.Drawing.Size(324, 29);
            this.common_btn.TabIndex = 10;
            this.common_btn.Text = "button1";
            this.common_btn.UseVisualStyleBackColor = true;
            // 
            // LoginRegisterControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.common_btn);
            this.Controls.Add(this.txbx_password);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.txbx_email);
            this.Controls.Add(this.lbl_email);
            this.Name = "LoginRegisterControl";
            this.Size = new System.Drawing.Size(327, 172);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txbx_password;
        private System.Windows.Forms.Label lbl_password;
        public System.Windows.Forms.TextBox txbx_email;
        private System.Windows.Forms.Label lbl_email;
        public System.Windows.Forms.Button common_btn;
    }
}
