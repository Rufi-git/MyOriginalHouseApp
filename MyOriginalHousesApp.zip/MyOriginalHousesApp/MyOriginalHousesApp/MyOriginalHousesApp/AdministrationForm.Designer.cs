﻿namespace MyOriginalHousesApp
{
    partial class AdministrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txbx_address = new System.Windows.Forms.TextBox();
            this.lbl_address = new System.Windows.Forms.Label();
            this.txbx_price = new System.Windows.Forms.TextBox();
            this.lbl_price = new System.Windows.Forms.Label();
            this.add_home_btn = new System.Windows.Forms.Button();
            this.lbl_welcome = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_home_count = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txbx_address
            // 
            this.txbx_address.Location = new System.Drawing.Point(12, 117);
            this.txbx_address.Name = "txbx_address";
            this.txbx_address.Size = new System.Drawing.Size(324, 20);
            this.txbx_address.TabIndex = 7;
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.Location = new System.Drawing.Point(9, 96);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(74, 18);
            this.lbl_address.TabIndex = 6;
            this.lbl_address.Text = "Address:";
            // 
            // txbx_price
            // 
            this.txbx_price.Location = new System.Drawing.Point(12, 44);
            this.txbx_price.Name = "txbx_price";
            this.txbx_price.Size = new System.Drawing.Size(324, 20);
            this.txbx_price.TabIndex = 5;
            // 
            // lbl_price
            // 
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_price.Location = new System.Drawing.Point(9, 23);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(52, 18);
            this.lbl_price.TabIndex = 4;
            this.lbl_price.Text = "Price:";
            // 
            // add_home_btn
            // 
            this.add_home_btn.Location = new System.Drawing.Point(12, 161);
            this.add_home_btn.Name = "add_home_btn";
            this.add_home_btn.Size = new System.Drawing.Size(324, 30);
            this.add_home_btn.TabIndex = 8;
            this.add_home_btn.Text = "Add Home";
            this.add_home_btn.UseVisualStyleBackColor = true;
            this.add_home_btn.Click += new System.EventHandler(this.add_home_btn_Click);
            // 
            // lbl_welcome
            // 
            this.lbl_welcome.AutoSize = true;
            this.lbl_welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_welcome.Location = new System.Drawing.Point(412, 44);
            this.lbl_welcome.Name = "lbl_welcome";
            this.lbl_welcome.Size = new System.Drawing.Size(0, 16);
            this.lbl_welcome.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(412, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Added Home:";
            // 
            // lbl_home_count
            // 
            this.lbl_home_count.AutoSize = true;
            this.lbl_home_count.Location = new System.Drawing.Point(490, 120);
            this.lbl_home_count.Name = "lbl_home_count";
            this.lbl_home_count.Size = new System.Drawing.Size(0, 13);
            this.lbl_home_count.TabIndex = 11;
            // 
            // AdministrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 267);
            this.Controls.Add(this.lbl_home_count);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_welcome);
            this.Controls.Add(this.add_home_btn);
            this.Controls.Add(this.txbx_address);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.txbx_price);
            this.Controls.Add(this.lbl_price);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AdministrationForm";
            this.Text = "AdministrationForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AdministrationForm_FormClosed);
            this.Load += new System.EventHandler(this.AdministrationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbx_address;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.TextBox txbx_price;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Button add_home_btn;
        private System.Windows.Forms.Label lbl_welcome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_home_count;
    }
}