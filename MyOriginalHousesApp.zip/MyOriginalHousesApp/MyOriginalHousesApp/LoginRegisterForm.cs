﻿using MyOriginalHousesApp.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyOriginalHousesApp
{
    public partial class LoginRegisterForm : Form
    {
        public LoginRegisterForm()
        {
            InitializeComponent();
            registerControl.common_btn.Text = "Register";
            loginControl.common_btn.Text = "Login";

            registerControl.common_btn.Click += Register_btn_Click;
            loginControl.common_btn.Click += Login_btn_Click;

            registered_users_count.Text = Users.UsersCount().ToString();
        }

        private void Register_btn_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.Name = txbx_name.Text;
            user.Surname = txbx_surname.Text;
            user.Age = Convert.ToByte(txbx_age.Text);
            user.Email = registerControl.txbx_email.Text;
            user.Password = registerControl.txbx_password.Text;

            if(Users.GetUserByEmail(user.Email) == null)
            {
                Users.Add(user);
                registered_users_count.Text = Users.UsersCount().ToString();
                MessageBox.Show("Uğurla qeydiyyatdan keçdiniz!");
            }
            else
            {
                MessageBox.Show("This email has already been used!");
            }
        }

        private void Login_btn_Click(object sender, EventArgs e)
        {
            string email = loginControl.txbx_email.Text;
            string password = loginControl.txbx_password.Text;

            if(Users.GetUserByParams(email, password) != null)
            {
                AdministrationForm administrationForm = new AdministrationForm();
                Session.CurrentUser = Users.GetUserByParams(email, password);
                Session.MainForm = this;
                this.Hide();
                administrationForm.ShowDialog();
                //MessageBox.Show("Siz ugurla daxil oldunuz!");
            }
            else
            {
                MessageBox.Show("Daxil olma basarisiz oldu!");
            }
        }

        private void LoginRegisterForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.HomeForm.Close();
        }
    }
}
