﻿namespace MyOriginalHousesApp
{
    partial class LoginRegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name = new System.Windows.Forms.Label();
            this.txbx_name = new System.Windows.Forms.TextBox();
            this.txbx_surname = new System.Windows.Forms.TextBox();
            this.lbl_surname = new System.Windows.Forms.Label();
            this.txbx_age = new System.Windows.Forms.TextBox();
            this.lbl_age = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.registered_users_count = new System.Windows.Forms.Label();
            this.loginControl = new MyOriginalHousesApp.Components.LoginRegisterControl();
            this.registerControl = new MyOriginalHousesApp.Components.LoginRegisterControl();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(12, 22);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(57, 18);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "Name:";
            // 
            // txbx_name
            // 
            this.txbx_name.Location = new System.Drawing.Point(15, 43);
            this.txbx_name.Name = "txbx_name";
            this.txbx_name.Size = new System.Drawing.Size(324, 20);
            this.txbx_name.TabIndex = 1;
            // 
            // txbx_surname
            // 
            this.txbx_surname.Location = new System.Drawing.Point(15, 116);
            this.txbx_surname.Name = "txbx_surname";
            this.txbx_surname.Size = new System.Drawing.Size(324, 20);
            this.txbx_surname.TabIndex = 3;
            // 
            // lbl_surname
            // 
            this.lbl_surname.AutoSize = true;
            this.lbl_surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_surname.Location = new System.Drawing.Point(12, 95);
            this.lbl_surname.Name = "lbl_surname";
            this.lbl_surname.Size = new System.Drawing.Size(80, 18);
            this.lbl_surname.TabIndex = 2;
            this.lbl_surname.Text = "Surname:";
            // 
            // txbx_age
            // 
            this.txbx_age.Location = new System.Drawing.Point(15, 189);
            this.txbx_age.Name = "txbx_age";
            this.txbx_age.Size = new System.Drawing.Size(324, 20);
            this.txbx_age.TabIndex = 5;
            // 
            // lbl_age
            // 
            this.lbl_age.AutoSize = true;
            this.lbl_age.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_age.Location = new System.Drawing.Point(12, 168);
            this.lbl_age.Name = "lbl_age";
            this.lbl_age.Size = new System.Drawing.Size(41, 18);
            this.lbl_age.TabIndex = 4;
            this.lbl_age.Text = "Age:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(472, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Registered users:";
            // 
            // registered_users_count
            // 
            this.registered_users_count.AutoSize = true;
            this.registered_users_count.Location = new System.Drawing.Point(567, 240);
            this.registered_users_count.Name = "registered_users_count";
            this.registered_users_count.Size = new System.Drawing.Size(0, 13);
            this.registered_users_count.TabIndex = 9;
            // 
            // loginControl
            // 
            this.loginControl.Location = new System.Drawing.Point(472, 22);
            this.loginControl.Name = "loginControl";
            this.loginControl.Size = new System.Drawing.Size(327, 172);
            this.loginControl.TabIndex = 7;
            // 
            // registerControl
            // 
            this.registerControl.Location = new System.Drawing.Point(15, 240);
            this.registerControl.Name = "registerControl";
            this.registerControl.Size = new System.Drawing.Size(327, 172);
            this.registerControl.TabIndex = 6;
            // 
            // LoginRegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 463);
            this.Controls.Add(this.registered_users_count);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.loginControl);
            this.Controls.Add(this.registerControl);
            this.Controls.Add(this.txbx_age);
            this.Controls.Add(this.lbl_age);
            this.Controls.Add(this.txbx_surname);
            this.Controls.Add(this.lbl_surname);
            this.Controls.Add(this.txbx_name);
            this.Controls.Add(this.lbl_name);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "LoginRegisterForm";
            this.Text = "LoginRegisterForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoginRegisterForm_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txbx_name;
        private System.Windows.Forms.TextBox txbx_surname;
        private System.Windows.Forms.Label lbl_surname;
        private System.Windows.Forms.TextBox txbx_age;
        private System.Windows.Forms.Label lbl_age;
        private Components.LoginRegisterControl registerControl;
        private Components.LoginRegisterControl loginControl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label registered_users_count;
    }
}