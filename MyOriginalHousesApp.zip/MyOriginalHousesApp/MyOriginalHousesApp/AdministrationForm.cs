﻿using MyOriginalHousesApp.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyOriginalHousesApp
{
    public partial class AdministrationForm : Form
    {
        public AdministrationForm()
        {
            InitializeComponent();
        }

        private void AdministrationForm_Load(object sender, EventArgs e)
        {
            lbl_welcome.Text = "Welcome " + Session.CurrentUser.Email;
            lbl_home_count.Text = Houses.UserHomeCount(Session.CurrentUser.Email).ToString();
        }

        private void AdministrationForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Session.MainForm.Close();
        }

        private void add_home_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Seller = Session.CurrentUser.Email;
            home.Address = txbx_address.Text;
            home.Price = Convert.ToDecimal(txbx_price.Text);

            Houses.Add(home);
            lbl_home_count.Text = Houses.UserHomeCount(Session.CurrentUser.Email).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Session.HomeForm = this;
            LoginRegisterForm loginRegisterForm = new LoginRegisterForm();
            loginRegisterForm.ShowDialog();
        }
    }
}
